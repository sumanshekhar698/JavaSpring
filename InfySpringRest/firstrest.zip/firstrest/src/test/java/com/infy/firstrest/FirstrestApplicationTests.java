package com.infy.firstrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
